package hn.edu.ujcv.proyecto1.clases

import java.util.*

class Prestamos {
    private var numeroPrestamo: Int =0
    private var fechaPrestamos= Date()
    private var fechaDevolucion = Date()

    constructor(){}
    fun setFechaPrestamos(year:Int,month:Int,date:Int){
        fechaPrestamos = Date(year,month,date)
    }
    fun getFechaPrestamos():Date{
        return fechaPrestamos
    }
    fun NumeroPrestamos():Int{
        return numeroPrestamo+1
    }
    fun setFechaDevolucion(date: Int,month: Int,year: Int){
         fechaDevolucion = Date(year, month, date)
    }
    fun getFechaDevolucion():Date{
        return fechaDevolucion
    }


}