package hn.edu.ujcv.proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hn.edu.ujcv.proyecto1.clases.Libros
import kotlinx.android.synthetic.main.activity_libro.*

class LibroActivity : AppCompatActivity() {
    val valores: HashMap<Int,String> = hashMapOf()
    var numero = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_libro)
        inicializar()
        btnGuardar.setOnClickListener { guardar() }
        btnAtras.setOnClickListener { onBackPressed() }
        btnEnviar.setOnClickListener { enviar() }
    }

    private fun enviar() {
        val intent= Intent(this,VisualizarLibrosActivity::class.java)
        intent.putExtra("valores", valores)
        startActivity(intent)
    }

    private fun guardar() {

        val datosLibro = StringBuilder()
        numero+=1
        datosLibro.append(txtNombreLibro.text.toString().trim()).append("|")
        datosLibro.append(txtAutor.text.toString().trim()).append("|")
        datosLibro.append(txtFecha.text.toString().trim()).append("|")
        datosLibro.append(txtEditorial.text.toString().trim())
        valores.put(numero,datosLibro.toString())
        btnEnviar.isEnabled= true

    }

    private fun inicializar() {
        btnEnviar.isEnabled = false
    }
}