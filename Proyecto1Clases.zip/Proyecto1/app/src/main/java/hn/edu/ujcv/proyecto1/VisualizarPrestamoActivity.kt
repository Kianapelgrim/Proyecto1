package hn.edu.ujcv.proyecto1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hn.edu.ujcv.proyecto1.clases.Prestamos
import kotlinx.android.synthetic.main.activity_visualizar_prestamo.*

class VisualizarPrestamoActivity : AppCompatActivity() {
    var prestamoInfo :HashMap<Int, String> = hashMapOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visualizar_prestamo)
        btnBuscarPrestamo.setOnClickListener { buscarPrestamo() }

    }

    private fun buscarPrestamo() {
        var intent = intent
        prestamoInfo = intent.getSerializableExtra("prestamoInfo" ) as HashMap<Int, String>
        var prestamo =Prestamos()

    }
}