package hn.edu.ujcv.proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import hn.edu.ujcv.proyecto1.clases.Libros
import kotlinx.android.synthetic.main.activity_visualizar_libros.*




class VisualizarLibrosActivity : AppCompatActivity() {
    var valores: HashMap<Int, String> = hashMapOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visualizar_libros)
        btnBuscar.setOnClickListener { visualizar() }
    }

    private fun visualizar() {
        var intent = intent
        valores = intent.getSerializableExtra("valores") as HashMap<Int, String>
        val libros = Libros()
        var numeroBuscar : Int
        numeroBuscar = txtNumeroLibroVisualizar.text.toString().toInt()
        for (valor in valores) {
            if (valores.containsKey(numeroBuscar)) {
                val lista = valor.toString().split("|").toTypedArray()
//                libros.setNumeroLibro(lista[1].toString().toInt())
                libros.setNombreLibro(lista[0].toString())
                libros.setNombreAutor(lista[1].toString())
                libros.setFecha(lista[2].toString())
                libros.setEditorial(lista[3].toString())
            }else {
                val alertDialog = AlertDialog.Builder(this)
                alertDialog.setMessage("No se encontro nada")
            }
        }
            txvNombreLibro.text = libros.getNombreLibro()
            txvAutor.text = libros.getAutor()
            txvFechaPublicacion.text = libros.getFecha()
            txvEditorial.text = libros.getEditorial()
    }
}