package hn.edu.ujcv.proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import hn.edu.ujcv.proyecto1.clases.Alumno
import kotlinx.android.synthetic.main.activity_alumno.*
import kotlinx.android.synthetic.main.activity_alumno.btnEnviar
import kotlinx.android.synthetic.main.activity_alumno.btnGuardar
import kotlinx.android.synthetic.main.activity_libro.*
import java.lang.StringBuilder


class AlumnoActivity : AppCompatActivity() {
    var alumnos: HashMap<Int, String> = hashMapOf()
    var numero :Int= 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alumno)
        btnGuardar.setOnClickListener { agregar() }
        btnAtrasAlumno.setOnClickListener { onBackPressed() }
        btnEnviar.setOnClickListener { enviar() }
    }

    private fun enviar() {
        val intent = Intent(this, VisualizarAlumnoActivity::class.java)
        intent.putExtra("alumnos", alumnos)

    }



    private fun agregar(){
        if(txtFechaIngresoAlumno.text.toString().isEmpty()&&txtNumeroCuentaAlumno.text.toString()
                .isEmpty()&&txtCorreAgregar.text.toString().isEmpty()&&
            txtCarreraAlumno.text.toString().isEmpty()&&txtNombreAlumnoAgregar.text.toString().isEmpty())
            {
            Toast.makeText(this,"Por favor ingrese todas las opciones",Toast.LENGTH_SHORT).show()
        }else {
            numero = txtNumeroCuentaAlumno.text.toString().toInt()
//            numero++
            var alumnosDatos = StringBuilder()
            alumnosDatos.append(txtNombreAlumnoAgregar.text.toString().trim()).append("|")
            alumnosDatos.append(txtCarreraAlumno.text.toString().trim()).append("|")
            alumnosDatos.append(txtFechaIngresoAlumno.text.toString().trim()).append("|")
            alumnosDatos.append(txtCorreAgregar.text.toString().trim())
            alumnos.put(numero, alumnosDatos.toString())
        }
    }
}