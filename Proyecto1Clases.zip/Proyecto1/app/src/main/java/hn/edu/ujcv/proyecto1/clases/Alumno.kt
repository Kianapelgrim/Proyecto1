package hn.edu.ujcv.proyecto1.clases

class Alumno {
    private var nombre: String =""
    private var carrera: String =""
    private var ingreso: String =""
    private var correo: String =""
    private var numCuenta: Int =0

    fun getNombre(): String {
        return nombre
    }
    fun getCarrera(): String {
        return carrera
    }
    fun getIngreso(): String {
        return ingreso
    }
    fun getCorreo(): String {
        return correo
    }
    fun getNumCuenta():Int {
        return numCuenta
    }
    fun setCarrera(carrera: String){
        this.carrera = carrera
    }
    fun setIngreso(ingreso: String){
        this.ingreso=ingreso
    }
    fun setCorreo(correo: String){
        this.correo=correo
    }
    fun setNumCuenta(numCuenta: Int){
        this.numCuenta=numCuenta
    }
    fun setNombre(nombre: String){
        this.nombre=nombre
    }



}