package hn.edu.ujcv.proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_prestamo.*
import kotlinx.android.synthetic.main.activity_prestamo.view.*

class PrestamoActivity : AppCompatActivity() {
    val prestamoInformer : HashMap<Int, String> = hashMapOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prestamo)
        btnGuardarPrestamo.setOnClickListener { registrarPrestamo() }
        btnEnviarPrestamo.setOnClickListener { enviarPrestamo() }
        btnAtrasPrestamo.setOnClickListener { onBackPressed() }
    }

    private fun enviarPrestamo() {
        val intent = Intent(this,VisualizarPrestamoActivity::class.java)
        intent.putExtra("prestamoInfo" , prestamoInformer)

    }

    private fun registrarPrestamo() {
        var datoPrestamos = StringBuilder()
        datoPrestamos.append(txtNumerodePrestamo.text.toString().trim()).append("|")
        datoPrestamos.append(txtFechaPrestamo.txtFechaPrestamo.text.toString().trim()).append("|")
        datoPrestamos.append(txtNumeroLibroPrestamo.text.toString().trim()).append("|")
        datoPrestamos.append(txtNumeroCuentaPrestamo.text.toString().trim()).append("|")
        prestamoInformer.put(txtNumerodePrestamo.text.toString().toInt(),datoPrestamos.toString())

    }
}