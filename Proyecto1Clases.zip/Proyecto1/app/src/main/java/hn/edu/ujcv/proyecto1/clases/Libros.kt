package hn.edu.ujcv.proyecto1.clases

class Libros() {
    private var numeroLibro: Int =0
    private var nombreAutor: String = ""
    private var nombreLibro : String=""
    private var editorial: String =""
    private var fecha : String = ""

    fun setFecha (fecha:String){
        this.fecha = fecha

    }
    fun getFecha():String{
        return fecha
    }
    fun setNumeroLibro(bookNumber:Int){
        this.numeroLibro = bookNumber
    }
    fun getNumeroLibro():Int{
        return numeroLibro
    }
    fun setNombreLibro(bookName:String ){
        this.nombreLibro = bookName
    }
    fun getNombreLibro ():String{
        return nombreLibro
    }
    fun setEditorial(editorial:String ){
        this.editorial=editorial
    }
    fun getEditorial():String{
        return editorial
    }
    fun setNombreAutor(author:String){
        this.nombreAutor = author
    }
    fun getAutor():String{
        return nombreAutor
    }
}