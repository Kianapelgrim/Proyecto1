package hn.edu.ujcv.proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hn.edu.ujcv.proyecto1.clases.Libros
import hn.edu.ujcv.proyecto1.clases.Prestamos
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.HashMap

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnRegistrarAlumno.setOnClickListener { registrarAlumnos() }
        btnRegistrarLibro.setOnClickListener { registrarLibros() }
        btnVisualizarLibros.setOnClickListener { visualizarLibros() }
        btnVisualizarAlumnos.setOnClickListener { visualizarAlumnos() }
        btnRegistrarPrestamo.setOnClickListener { prestamos() }
        btnVisualizarPrestamos.setOnClickListener { visualizarPrestamos() }


//        val libros : Libros = Libros()


    }

    private fun visualizarPrestamos() {
        val intent = Intent(this,VisualizarPrestamoActivity::class.java)
        startActivity(intent)
    }

    private fun prestamos() {

    }

    //
//    private fun test() {
//        val intent = Intent(this,TestActivity::class.java)
//        startActivity(intent)
//    }
//
    private fun visualizarAlumnos() {
        val intent = Intent(this,PrestamoActivity::class.java)
        startActivity(intent)
    }

    private fun visualizarLibros() {
        val intent = Intent(this,VisualizarLibrosActivity::class.java)
        startActivity(intent)
    }

    private fun registrarLibros() {
        val intent = Intent(this,LibroActivity::class.java )
        startActivity(intent)
    }

    private fun registrarAlumnos() {
        val intent = Intent(this,AlumnoActivity::class.java)
        startActivity(intent)

    }



    private fun fechaDevolucion() {


    }


}