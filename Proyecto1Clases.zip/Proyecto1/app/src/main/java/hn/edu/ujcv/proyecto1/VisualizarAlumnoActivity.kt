package hn.edu.ujcv.proyecto1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hn.edu.ujcv.proyecto1.clases.Alumno
import kotlinx.android.synthetic.main.activity_visualizar_alumno.*
import android.view.View



class VisualizarAlumnoActivity : AppCompatActivity() {
    private var informacionAlumno : HashMap<Int, String> = hashMapOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visualizar_alumno)
        btnBuscarAlumno .setOnClickListener { buscarAlumno() }
    }


    private fun buscarAlumno() {
        val intent = intent
        informacionAlumno = intent.getSerializableExtra("alumnos") as HashMap<Int , String>
        val alumnox = Alumno()
        val numeroCuentaBusqueda : Int = txtNumeroCuentaBuscar.text.toString().toInt()

        for (dato in informacionAlumno){
            if(informacionAlumno.containsKey(numeroCuentaBusqueda)) {
                val listaAlumnos = dato.toString().split("|").toTypedArray()
                alumnox.setNombre(listaAlumnos[0])
                alumnox.setCarrera(listaAlumnos[1])
                alumnox.setIngreso(listaAlumnos[2])
                alumnox.setCorreo(listaAlumnos[3])
                alumnox.setNumCuenta(listaAlumnos[4].toInt())
            }
        }
        txvCarreraVisualizar.     text = alumnox.getCarrera()
        txvCorreoAlumnoVisualizar.text = alumnox.getCorreo()
        txvNombreAlumnoVisualizar.text = alumnox.getNombre()
        txvFechaIngresoVisualizar.text = alumnox.getIngreso()

    }


}